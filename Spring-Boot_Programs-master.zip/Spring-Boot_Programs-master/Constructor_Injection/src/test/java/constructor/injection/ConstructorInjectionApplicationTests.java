package constructor.injection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConstructorInjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
