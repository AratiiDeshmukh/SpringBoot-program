package cofee.production;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeProductionHouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
