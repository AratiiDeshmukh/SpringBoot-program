package anudip.link;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnudipHomePageLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnudipHomePageLinkApplication.class, args);
	}

}
